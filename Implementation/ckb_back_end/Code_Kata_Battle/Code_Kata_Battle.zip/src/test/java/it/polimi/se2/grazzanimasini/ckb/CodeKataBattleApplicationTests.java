package it.polimi.se2.grazzanimasini.ckb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeKataBattleApplicationTests {

	@Test
	void contextLoads() {
	}


}
