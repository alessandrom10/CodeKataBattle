package it.polimi.se2.grazzanimasini.ckb.controllers.model;

public enum UserBattleStatus {
    EXTERNAL,
    ENROLLED,
    MANAGING
}
