package it.polimi.se2.grazzanimasini.ckb.database.model;

public enum NotificationCategory {
    TOURNAMENT_MANAGE_INVITATION,
    GROUP_PARTECIPATION_INVITATION,
    GENERIC_NOTIFICATION
}
