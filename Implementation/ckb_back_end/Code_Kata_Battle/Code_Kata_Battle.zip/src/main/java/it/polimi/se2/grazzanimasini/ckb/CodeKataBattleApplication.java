package it.polimi.se2.grazzanimasini.ckb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeKataBattleApplication {

	public static void main(String[] args) { SpringApplication.run(CodeKataBattleApplication.class, args); }

}
